This is a test to write some java code to read in a text file and answer 3 simple questions

The instructions for the test, the "main" method, and some code to get you started are in the class:
com.rightmove.ManipulateDataApplication (located in the /src directory)

Important:
 * We do not expect you to spend more than an hour on this test, a good code design is preferable to a working finished product.
 * You are not required to write any tests or provide any build scripts etc. We are only going to look at your code.
 * We have provided IntelliJ IDEA and eclipse project files for your convenience, but you can ignore, delete or replace them.
 * When you have finished, please zip this directory and email it back to us.
