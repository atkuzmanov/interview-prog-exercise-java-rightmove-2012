package com.rightmove;

import java.io.*;

/**
 * Please read in the data contained within the file manipulate-data.txt
 * Manipulate the data to programmatically answer the following questions:
 * 
 * 1. How many people in the list are male? 
 * 2. In years what is the average age of the people in the list? 
 * 3. How many days older is Jeff Briton than Tom Soyer?
 * 
 * You may add comments to your code to tell us why you chose to do something a
 * particular way, but this is not required. You may create as many classes as
 * you like. You may delete any code in ManipulateDataApplication that you don't
 * want.
 * 
 * Please print your answers out to the screen by using the 'System.out.print'
 * function. Good Luck!
 */

public class ManipulateDataApplication {

	public static void main(String[] args) throws IOException {
		File file = new File("manipulate-data.txt");
		System.out.println(file.getName() + " file exists = " + file.exists());

		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			helpfulMethodFeelFreeToDeleteOrUseElsewhere(line);
		}
		bufferedReader.close();
	}

	private static void helpfulMethodFeelFreeToDeleteOrUseElsewhere(String line) {
		String[] columns = line.split(",");
		for (String column : columns) {
			System.out.print(column);
		}
	}
}